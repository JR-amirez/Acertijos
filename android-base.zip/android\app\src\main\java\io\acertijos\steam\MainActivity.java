package io.acertijos.steam;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
